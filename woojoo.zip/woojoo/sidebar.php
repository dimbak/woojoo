<div id="sidebar1" class="sidebar large-2 medium-4 columns" role="complementary">

	<?php if ( is_active_sidebar( 'footer-left' ) && is_front_page() ) { ?>

			<?php dynamic_sidebar( 'footer-left' ); ?>

	<?php } else if ( is_home() ) { ?>

			<?php dynamic_sidebar( 'blog'); ?>
	
	<?php } ?>
	
</div>