			
				<footer class="footer" role="contentinfo">
					<div id="inner-footer" class="row expanded">
						
						<div class="small-6 large-6 columns">
						
							<?php dynamic_sidebar( 'footer-left'); ?>
						
						</div>
						<div class="small-6 large-6 columns">
							
	    					<?php dynamic_sidebar( 'footer-right' ); ?>
	    					
	    				</div>
					</div> <!-- end #inner-footer -->
				</footer> <!-- end .footer -->
				
			</div>  <!-- end .main-content -->
		</div> <!-- end .off-canvas-wrapper -->
		<?php wp_footer(); ?>
	</body>
</html> <!-- end page -->