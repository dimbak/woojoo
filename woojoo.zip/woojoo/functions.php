<?php
// Theme support options
require_once(get_template_directory().'/assets/functions/theme-support.php'); 

// WP Head and other cleanup functions
require_once(get_template_directory().'/assets/functions/cleanup.php'); 

// Register scripts and stylesheets
require_once(get_template_directory().'/assets/functions/enqueue-scripts.php'); 

// Register custom menus and menu walkers
require_once(get_template_directory().'/assets/functions/menu.php'); 

// Register sidebars/widget areas
require_once(get_template_directory().'/assets/functions/sidebar.php'); 

// Makes WordPress comments suck less
require_once(get_template_directory().'/assets/functions/comments.php'); 

// Replace 'older/newer' post links with numbered navigation
require_once(get_template_directory().'/assets/functions/page-navi.php'); 

// Adds support for multiple languages
require_once(get_template_directory().'/assets/translation/translation.php'); 


// Remove 4.2 Emoji Support
// require_once(get_template_directory().'/assets/functions/disable-emoji.php'); 

// Adds site styles to the WordPress editor
//require_once(get_template_directory().'/assets/functions/editor-styles.php'); 

// Related post function - no need to rely on plugins
// require_once(get_template_directory().'/assets/functions/related-posts.php'); 

// Use this as a template for custom post types
// require_once(get_template_directory().'/assets/functions/custom-post-type.php');

// Customize the WordPress login menu
// require_once(get_template_directory().'/assets/functions/login.php'); 

// Customize the WordPress admin
// require_once(get_template_directory().'/assets/functions/admin.php'); 



// WOOJOO

// Unset default WC layout CSS

function woojoo_dequeue_styles( $enqueue_styles ) {
	
	unset( $enqueue_styles['woocommerce-layout'] );
	
	return $enqueue_styles;
}

add_filter( 'woocommerce_enqueue_styles', 'woojoo_dequeue_styles' );

// add WC product gallery effects / scripts 

add_theme_support( 'wc-product-gallery-zoom' );
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );


// make theme compatible with WC
// https://docs.woocommerce.com/document/third-party-custom-theme-compatibility/

remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );

add_action('woocommerce_before_main_content', 'woojoo_wrapper_start', 10);
add_action('woocommerce_after_main_content', 'woojoo_wrapper_end', 10);


function woojoo_wrapper_start() {

	echo '<div id="content">';
	echo '<div class="row">';
	echo '<div class="large-12 columns">';
	
}

function woojoo_wrapper_end() {

	echo '</div>';
	echo '</div>';
	echo '</div>';

}

add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {

	add_theme_support( 'woocommerce' );

}