<div class="row expanded">
	
	<div class="small-5 medium-4 large-2 columns">
		<?php //the_custom_logo(); ?>
		<span class="bwsteps-logo">
			<?php echo '<a href="' .esc_url( home_url( '/' ) ).'">'.get_bloginfo().'</a>';
			//get_permalink(); '"'>get_bloginfo()</a>'; ?>
				
			</span>
	</div>
	<div class="medium-6 large-8 columns show-for-medium" >
		
				<?php joints_top_nav(); ?>	
		
	</div>
	<div class="medium-2 large-2 columns show-for-medium " >
		
			<div class="wcicon-cart">
				<a class="cart-customlocation" style="outline:0px solid red;" href="<?php echo wc_get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>"><?php echo sprintf ( _n( '%d item', '%d items', WC()->cart->get_cart_contents_count() ), WC()->cart->get_cart_contents_count() ); ?>
				</a>
			</div>
		

	</div>
	<div class="top-bar-right float-right show-for-small-only">
		<ul class="menu">
			<!-- <li><button class="menu-icon" type="button" data-toggle="off-canvas"></button></li> -->
			<li><a data-toggle="off-canvas"><?php _e( 'Menu', 'jointswp' ); ?></a></li>
		</ul>
	</div>
</div>
