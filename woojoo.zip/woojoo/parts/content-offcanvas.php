<div class="off-canvas position-right" id="off-canvas" data-off-canvas>
	<div style="margin-bottom:20px;">
		<button class="close-button" aria-label="Close menu" type="button" data-close>
  			<span aria-hidden="true">&times;</span>
		</button>
	</div>
	<?php joints_off_canvas_nav(); ?>
	<div class="woojoo-wcicon-cart">
			<span class="wcicon-cart"><a class="cart-customlocation" href="<?php echo wc_get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>"><?php echo sprintf ( _n( '%d item', '%d items', WC()->cart->get_cart_contents_count() ), WC()->cart->get_cart_contents_count() ); ?> - <?php echo WC()->cart->get_cart_total(); ?></a>
			</span>
		</div>

</div>